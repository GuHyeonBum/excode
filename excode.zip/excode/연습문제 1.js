// 1
let name = "HOPE";
let speed = 17500;
let MilesPerKm = 0.621;
let distanceMars = 225000000;
let distanceMoon = 384400;
let weightspaceship = 5500;
let weightfuel = 1100;

let speedkm = speed / MilesPerKm;
let timeMarse = distanceMars / speedkm;

console.log("우주선 " + name + "는 화성까지 " + timeMarse + "시간 걸립니다.");


let moonTime = distanceMoon / speedkm;

console.log("우주선 " + name + "는 달까지 " + moonTime + "시간 걸립니다.");


let launchWeight = weightspaceship + weightfuel;

console.log("우주선 " + name + "의 발사무게는 " + launchWeight + "kg 입니다.");

//2-1_1
console.log(15 - 5 * (7 + 2 * 3) ** 2);

console.log(5 * (2 + (5 - 3) / 4) * 128);

console.log(((3 ** 3 - 2) % 5 + 2) ** 2);

//2-1_2

const x = 2;
const y = 3;

console.log(x ** (2 * y) * (x + 5) * Math.log2(x));

console.log(x * Math.sqrt(2 - 2 * Math.sin(y)));

//2-1_3
const r = 5;

console.log(Math.PI * r ** 2);

//2-1_4
const a = 1;
const b = -3;
const c = 2;

const x1 = (-b + Math.sqrt(b ** 2 - 4 * a * c)) / (2 * a);
const x2 = (-b - Math.sqrt(b ** 2 - 4 * a * c)) / (2 * a);

console.log(x1);
console.log(x2);

//2-2_1
console.log(10 > 5);

console.log(10 === "10");

console.log(10 == "10");

console.log(5 >= 5);

console.log(3 != "3");

console.log(3 !== "3");

console.log(10 > 5 && 3 < 2);

console.log(10 > 5 || 3 < 2)

//2-2_2
console.log("apple" > "banana");

console.log(5 > 3 === true);

const a = 10;
const b = "10";

console.log(a == b && a !== b);

const x = 20;

console.log(x >= 10 && x <= 20);
