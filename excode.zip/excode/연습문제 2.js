//2-2_1

console.log(10>5);
console.log(10 === "10");
console.log(10 =="10");
console.log(5>=5);
console.log(3 != "3")
console.log(3 !== "3");
console.log(10<5 && 3<2);
console.log(10>5 || 3<2);

//2-2_2

console.log("apple">"banana");
console.log(5>3 === true);

const a =10;
const b = "10";
console.log(a==b && a !== b);

const X =20;
console.log(X>=10 && X<=20);

//2-3_1
console.log(true || false && false);
console.log((true || false) && false);
console.log(!(true||false) && true);
console.log(""||"JavaScript");

//2-3_2
const a = 0;
const b = 10;
console.log((a||b)&&20);

const a = "";
const b = "HELLO";
const c = "WORLD";
console.log(a||b&&c);

//2-3_3
const X = 10;
const Y = 20;
const Z = 30;
console.log(X && Y && Z);

const X = 0;
const Y = 10;
const Z = 20;
console,log(X || Y || Z);

//2-3_4
const x = 10;
const y = 20;
console.log( !(x>5 && y<10) || (x===10 && y===20) );

const x = 10;
console.log(x>5 && 0 || x<5);

