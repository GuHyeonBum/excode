//3-1
const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("정수 n을 입력하세요: ", function(input) {
    let n = parseInt(input);

    if (n % 2 !== 0) {
        console.log(n + "은 홀수입니다");
    } else {
        console.log(n + "은 짝수입니다");
    }

    rl.close();
});



//3-2
/*const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("년도를 입력하세요: ", function(year) {

    year = Number(year);

    if (year % 400 == 0) {
        console.log(year + "년은 윤년입니다.");
    } else if (year % 100 == 0) {
        console.log(year + "년은 평년입니다.");
    } else if (year % 4 == 0) {
        console.log(year + "년은 윤년입니다.");
    } else {
        console.log(year + "년은 평년입니다.");
    }

    rl.close();
});*/
