//4-1
/*let browser ='Edge';

if(browser === 'Edege') {
    console.log('Edge를 사용하고 계시네요!');
} else if(
    browser === 'Chrome' ||
    browser === 'Firefox' ||
    browser === 'Safari' ||
    browser === 'Opera'
) {
    console.log('저희 서비스가 지원하는 브라우저를 사용하고 계시네요.');
} else {
    console.log('good luck!');
}*/

//4-2
/*let a =2;
switch (a) {
    case 0:
        console.log(0);
        break;
        case 1:
        console.log(1);
        break;
        case 2:
        case 3:
        console.log('2,3');
        break;
}*/

//4-3
/*let i = 0;

while (i < 3) {
    console.log(`number ${i}`);
    i++;
}*/

//4-4
/*for (let dan = 1; dan <= 9; dan++) {

    console.log(`${dan}단`);

    for (let i = 1; i <= 9; i++) {
        console.log(`${dan} x ${i} = ${dan * i}`);
    }

    console.log('');
}*/

//4-5
/*for (let n=1; n<=100; n++) {
    if(n % 3 === 0 && n % 5 === 0) {
        console.log(`${n} : 3과 5의 배수입니다.`);
} else if(n % 3 === 0) {
    console.log(`${n} : 3의 배수입니다.`);
} else if(n % 5 === 0) {
    console.log(`${n} : 5의 배수입니다.`);
}

}

let n = 1;

while (n <= 100) {

    if (n % 3 == 0 && n % 5 == 0) {
        console.log(`${n}은 3과 5의 배수입니다`);
    } else if (n % 3 == 0) {
        console.log(`${n}은 3의 배수입니다`);
    } else if (n % 5 == 0) {
        console.log(`${n}은 5의 배수입니다`);
    }

    n++;
}*/

//4-6
/*for (let n =2; n <= 100; n++) {

    let isPrime = true;

    for(let i = 2; i < n; i++) {

        if(n%i === 0) {
            isPrime = false;
            break;
        }
}

    if(isPrime) {
        console.log(`${n}은 소수입니다.`);
}*/