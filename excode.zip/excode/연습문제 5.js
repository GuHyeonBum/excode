//5-1_1
/*function max(n1, n2) {
    if (n1 > n2) {
        return n1;
    } else {
        return n2;
    }
}

console.log(max(2, 5));*/

//5-1_2
/*function facorial(n) {
    let result = 1;

    for (let i = 1; i <= n; i++) {
        result = result * i;
    }
    return result;
}

console.log(facorial(5));*/

//5-1_3
/*function pibo(n) {
    let a =1;
    let b =1;

    if(n==1 || n==2) {
        return 1;
    }

    for (let i = 3; i <= n; i++) {
        let temp = a + b;
        a = b;
        b = temp;
    }   

    return b;
}

console.log(pibo(10));*/

//5-1_4
/*function calc(n1, n2, operator) {
    if (operator == '+') {
        return n1 + n2;
    } else if (operator == '-') {
        return n1 - n2;
    } else if (operator == '*') {
        return n1 * n2;
    } else if (operator == '/') {
        return n1 / n2;
    }
}

console.log(calc(10, 5, '+')); 
console.log(calc(10, 5, '-')); 
console.log(calc(10, 5, '*')); 
console.log(calc(10, 5, '/')); */

//5-2_1
/*const max = function(n1, n2) {
    if (n1 > n2) {
        return n1;
    } else {
        return n2;
    }   
};

console.log(max(2, 5));*/

//5-2_2
/*const facorial = function(n) {
    let result = 1;

    for (let i = 1; i <= n; i++) {
        result = result * i;
    }

    return result;
};

console.log(facorial(5));*/

//5-2_3
/*const pibo = function(n) {
    let a = 1;
    let b = 1;

    if (n == 1 || n == 2) {
        return 1;
    }

    for (let i = 3; i <= n; i++) {
        let temp = a + b;
        a = b;
        b = temp;
    }

    return b;
};

console.log(pibo(10));*/

//5-2_4
/*const calc = function(n1, n2, operator) {
    if (operator == '+') {
        return n1 + n2;
    } else if (operator == '-') {
        return n1 - n2;
    } else if (operator == '*') {
        return n1 * n2;
    } else if (operator == '/') {
        return n1 / n2;
    }
};

console.log(calc(3, 5, '+'));
console.log(calc(3, 5, '/'));*/

//5-3_1
/*const max = (n1, n2) => {
    if (n1 > n2) {
        return n1;
    } else {
        return n2;
    }
};

console.log(max(2, 5));*/

//5-3_2
/*const facorial = (n) => {
    let result = 1;

    for (let i = 1; i <= n; i++) {
        result = result * i;
    }

    return result;
};

console.log(facorial(5));*/

//5-3_3
/*const pibo = (n) => {
    let a = 1;
    let b = 1;
 
    if (n == 1 || n == 2) {
        return 1;
    }

    for (let i = 3; i <= n; i++) {
        let temp = a + b;
        a = b;
        b = temp;
    }

    return b;
};
console.log(pibo(10));*/

//5-3_4
/*const calc = (n1, n2, operator) => {
    if (operator == '+') {
        return n1 + n2;
    } else if (operator == '-') {
        return n1 - n2;
    } else if (operator == '*') {
        return n1 * n2;
    } else if (operator == '/') {
        return n1 / n2;
    }
};

console.log(calc(3, 5, '+'));
console.log(calc(3, 5, '/'));*/
