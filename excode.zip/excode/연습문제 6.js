//6-1
/*let user = {};

user.name = "John";
console.log(user);

user.surname = "Smith";
console.log(user);

user.name = "Pete";
console.log(user);

delete user.name;
console.log(user);
*/

//6-2
/*let salaries = {
    John: 100,
    Ann: 160,
    Pete: 130
};

let sum = 0;

for (let key in salaries) {
    sum += salaries[key];
}

console.log(sum);*/

//6-3
/*let calculator = {
    read(a, b) {
        this.a = a;
        this.b = b;
    },
    sum() {
        return this.a + this.b;
    },

    mul() {
        return this.a * this.b;
    }
};

calculator.read(3, 5);
console.log(calculator.sum());
console.log(calculator.mul());*/

//6-4
/*function Calculator() {
    this.read = function(a, b) {
        this.a = a;
        this.b = b;
    };

    this.sum = function() {
        return this.a + this.b;
    };

    this.mul = function() {
        return this.a * this.b;
    };
}

let calculator = new Calculator();

calculator.read(1, 2);

console.log("Sum=" + calculator.sum());
console.log("Mul=" + calculator.mul());*/