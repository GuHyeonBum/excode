//7-1-1
/*let n = 2025;
let str = n.toString();
let sum = 0;

for (let i = 0; i < str.length; i++) {
    sum += parseInt(str[i]);
}

console.log(sum);*/

//7-1-2
/*function sumNumber(str) {
    let sum = 0;

    for (let i = 0; i < str.length; i++) {
        if (!isNaN(parseInt(str[i]))) {
            sum += parseInt(str[i]);
        }   
    }
    return sum;
}

console.log(sumNumber("25misterm10.04 Mon"));*/

//7-1-3
/*function binaryToHex(n) {
    return "0x" + n.toString(16).toUpperCase();
}

let n = 0b11111110;

console.log(binaryToHex(n));*/

//7-2-1
/*function firstUpper(str) {
    return str[0].toUpperCase() + str.slice(1);
}

console.log(firstUpper("hello"));*/

//7-2-2
/*function middleSpace(str) {
    let mid = Math.floor(str.length / 2);

    return str.slice(0, mid) + " " + str.slice(mid+1);

}

console.log(middleSpace("javascript"));*/

//7-3
/*let styles = ["Jazz", "Blues"];
console.log(styles);

styles.push("Rock-n-Roll");
console.log(styles);

styles[Math.floor(styles.length / 2)] = "Classics";
console.log(styles);

console.log(styles.shift());
console.log(styles);

styles.unshift("Rap", "Reggae");
console.log(styles);

console.log(styles.pop());
console.log(styles);*/

//7-4
/*function removeValue(arr, value) {
    let result = [];

    for (let i = 0; i < arr.length; i++) {
        if (arr[i] !== value) {
            result.push(arr[i]);
        }
    }
    return result;
}   

let fruits = ["apple", "banana", "grape"];

console.log(removeValue(fruits, "banana"));*/

//7-5
/*let str = "javascript";
let arr = [];
let result = "";

for (let i = 0; i < str.length; i++) {
    arr.push(str[i]);
}

while (arr.length > 0) {
    result += arr.pop();
}

console.log(result);*/
